import{j as t,f as a}from"./index-BRBX7hDb.js";const o=({label:s})=>t.jsx(a.Label,{className:"col-span-4 sm:col-span-2 font-medium text-sm",children:s});export{o as L};
